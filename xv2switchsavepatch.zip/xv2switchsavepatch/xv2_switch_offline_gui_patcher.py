#!/usr/bin/env python3
"""
Dragon Ball Xenoverse 2 - Nintendo Switch Offline Save Patcher GUI v2.2

Drag savefile1.dat onto the included Windows BAT launcher, choose patches, and
write a separate encrypted Switch save. This tool uses the dynamic-size save
format and recalculates all known checksums.

The curated inventory ID lists reproduce the last known-working save developed
in the accompanying research/testing session. They are merged with existing
records, so unknown/new records already in the input save are preserved.
"""
from __future__ import annotations

import hashlib
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

# Tkinter is included with normal Windows Python installations.
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox
    from tkinter.scrolledtext import ScrolledText
except ImportError as exc:
    print(
        "ERROR: Tkinter is missing from this Python installation.\n"
        "Install a normal Python 3 build and read README_XV2_SWITCH_PATCHER.txt.",
        file=sys.stderr,
    )
    raise SystemExit(3) from exc

try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
except ImportError:
    # Use a GUI error when possible, while still giving a console message.
    msg = (
        "ERROR: The Python package 'cryptography' is missing.\n\n"
        "Run:\n  py -3 -m pip install cryptography\n\n"
        "Then reopen the launcher. See README_XV2_SWITCH_PATCHER.txt."
    )
    print(msg, file=sys.stderr)
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Missing dependency", msg)
        root.destroy()
    except Exception:
        pass
    raise SystemExit(2)


APP_VERSION = "2.2"
SECTION1_KEY = b"PR]-<Q9*WxHsV8rcW!JuH7k_ug:T5ApX"
SECTION1_COUNTER = b"_Y7]mD1ziyH#Ar=0"
HEADER_SIZE = 0x80
MAGIC = b"#SAV\x00"
EMPTY_INV = b"\xff\xff\xff\xff\xff\x00\x00\x00"

# Confirmed inventory tables, 512 records x 8 bytes each.
@dataclass(frozen=True)
class InventoryTable:
    label: str
    category: int
    start: int
    end: int

TABLES = {
    "tops": InventoryTable("Tops", 0x00, 0x1408, 0x2408),
    "bottoms": InventoryTable("Bottoms", 0x01, 0x2408, 0x3408),
    "gloves": InventoryTable("Gloves", 0x02, 0x3408, 0x4408),
    "shoes": InventoryTable("Shoes", 0x03, 0x4408, 0x5408),
    "accessories": InventoryTable("Accessories", 0x04, 0x5408, 0x6408),
    "super_souls": InventoryTable("Super Souls", 0x05, 0x6408, 0x7408),
}

# These reproduce the item records in the last known-working save. The final
# update clothing IDs 529-542 are included in each clothing part.
ID_SPECS = {
    "tops": "0-70,74,77-95,102-108,110-111,122-205,215,225,235-279,281-308,311-329,331-340,342-356,358-462,464-475,478-492,494-542",
    "bottoms": "0-70,74,77-95,102-108,110-111,122-205,215,225,235-302,305-310,312-317,320-327,329,331-340,342-345,348-357,414-415,417-418,420,422-426,451-453,455-462,478-484,486,495,497-504,529-542",
    "gloves": "0-4,6-7,11-23,26,28,31-32,34-40,45-46,49-50,52-57,60,62,65-67,69-70,74,77-95,103-104,106,108,110,123-124,126-127,131-132,134-135,141,145-164,171-176,183-194,235-242,245-251,260,264,266-270,272-274,278-279,282-288,293-302,305-308,310,313-317,321-328,331-332,336-340,342,346-347,349,351-354,356-357,412-414,416-418,423,452-453,455-456,459,461-463,478,480-489,495,499-500,529-542",
    "shoes": "0-43,45-62,64-70,74,77-95,102-104,106-108,110-111,122-143,145-205,215,225,235-279,282-283,285-294,296-302,305-308,310,312-317,320-329,331-340,342-357,412-420,422-426,451-453,455-463,478-489,495,497-502,504,529-542",
    "accessories": "0-33,35-92,94-158,165-195,197-204",
    "super_souls": "0-169,171-216,218-228,230-245,247-249,300-310,400-494,496-497,500-502,520-522,540-542,560-562,580-582,600-602,605-607,610-612,615-617,620-622,625-627,630-632,635-637,640-642,645-680,800-858,863,1000-1002",
}

# Confirmed regular Artwork ownership bitset. IDs are 1-based and stored LSB-first.
# 900 is the tested safe boundary for this Switch save layout. Higher IDs are
# intentionally not touched until their extension block is mapped.
ARTWORK_BITSET_OFFSET = 0x7B968
ARTWORK_SAFE_MAX_ID = 900

# Acquired/location-lookup flag blocks.
ACQUIRED_TOPS = 0x348
ACQUIRED_BOTTOMS = 0x388
ACQUIRED_GLOVES = 0x3C8
ACQUIRED_SHOES = 0x408
ACQUIRED_ACCESSORIES = 0x448
ACQUIRED_SUPER_SOULS = 0x488
ACQUIRED_BLOCK_SIZE = 0x40
SUPER_SOUL_EXTENSION = 0xB86F4  # 60 older extension entries + new confirmed Soul flag.
NEW_SHENRON_SOUL_ID = 863  # "I'll grant you just one wish" (6-star Festival Super Soul).

# TP medals are calculated as the sum of these two signed 32-bit fields.
# The game may normalize them after launch/save, so always calculate the second
# field relative to the first rather than writing a single absolute value.
TP_BASE_OFFSET = 0xD8
TP_ADJUST_OFFSET = 0xDC
TP_TARGET = 99_999

# Skill record tables. Each record is 8 bytes; byte 0 is the unlocked flag.
SKILL_BLOCKS = (
    ("Super Attacks", 0xB428, 539),
    ("Ultimate Attacks", 0xD428, 302),
    ("Evasive Skills", 0xF428, 69),
    ("Awoken internal records", 0x15428, 48),
)

# Experimental lobby patch. It unlocked the tested mascots/auras, but it also
# changes TP calculation state. After using it, launch the game and create a
# fresh in-game save before feeding the save back into this patcher.
LOBBY_RISK_RANGE_1 = (0xC4, 0xCC)  # 8 bytes
LOBBY_RISK_RANGE_2 = (0xD4, 0xE0)  # 12 bytes

# Compact item record identities.
SUPER_MIX_Z = ("Super Mix Capsule Z", 0x06, 0x13, 0x7000, 0x7800)
ZEN_OH_BUTTON = ("Zen-Oh Button", 0x08, 0x20, 0x9000, 0x9600)


class SaveFormatError(ValueError):
    pass


@dataclass
class ParsedSave:
    raw: bytes
    section1: bytearray
    section2_encrypted: bytes
    section2: bytearray
    trailing: bytes


def parse_id_spec(spec: str) -> tuple[int, ...]:
    values: set[int] = set()
    for raw_part in spec.split(","):
        part = raw_part.strip()
        if not part:
            continue
        if "-" in part:
            left, right = part.split("-", 1)
            a, b = int(left), int(right)
            if b < a:
                a, b = b, a
            values.update(range(a, b + 1))
        else:
            values.add(int(part))
    return tuple(sorted(values))


TARGET_IDS = {key: parse_id_spec(value) for key, value in ID_SPECS.items()}


def aes_ctr_xv2(key: bytes, counter: bytes, data: bytes) -> bytes:
    out = bytearray(data)
    block = bytearray(counter)
    index = int.from_bytes(counter[-8:], "big")
    encryptor = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
    for offset in range(0, len(out), 16):
        block[-8:] = index.to_bytes(8, "big")
        stream = encryptor.update(bytes(block))
        for j, value in enumerate(stream):
            pos = offset + j
            if pos >= len(out):
                break
            out[pos] ^= value
        index = (index + 1) & ((1 << 64) - 1)
    encryptor.finalize()
    return bytes(out)


def checksum_every_0x20(buf: bytes) -> int:
    usable = len(buf) - (len(buf) % 0x20)
    return sum(buf[i] for i in range(0, usable, 0x20)) & 0xFF


def select_section2_crypto(section1: bytes) -> tuple[bytes, bytes]:
    if section1[5] & 4:
        return section1[0x4C:0x6C], section1[0x6C:0x7C]
    return section1[0x1C:0x3C], section1[0x3C:0x4C]


def update_header_checksums(section1: bytearray, section2_encrypted: bytes, section2_decrypted: bytes) -> None:
    section1[0:5] = MAGIC
    section1[0x7C:0x80] = len(section2_decrypted).to_bytes(4, "little")
    section1[0x1A] = checksum_every_0x20(section2_decrypted)
    section1[0x15] = sum(section1[0x06 + i] for i in range(14)) & 0xFF
    section1[0x16] = sum(section1[0x1C + i * 4] for i in range(8)) & 0xFF
    section1[0x17] = sum(section1[0x4C + i * 4] for i in range(8)) & 0xFF
    section1[0x18] = sum(section1[0x3C + i * 4] for i in range(4)) & 0xFF
    section1[0x19] = sum(section1[0x6C + i * 4] for i in range(4)) & 0xFF
    section1[0x1B] = checksum_every_0x20(section2_encrypted)
    section1[0x14] = (section1[0x05] + sum(section1[0x15 + i] for i in range(7))) & 0xFF


def validate(section1: bytes, section2_encrypted: bytes, section2_decrypted: bytes | None = None) -> list[str]:
    checks = {
        "Checksum1": (section1[0x14], (section1[0x05] + sum(section1[0x15 + i] for i in range(7))) & 0xFF),
        "Checksum2": (section1[0x1B], checksum_every_0x20(section2_encrypted)),
        "Checksum3": (section1[0x19], sum(section1[0x6C + i * 4] for i in range(4)) & 0xFF),
        "Checksum4": (section1[0x18], sum(section1[0x3C + i * 4] for i in range(4)) & 0xFF),
        "Checksum5": (section1[0x17], sum(section1[0x4C + i * 4] for i in range(8)) & 0xFF),
        "Checksum6": (section1[0x16], sum(section1[0x1C + i * 4] for i in range(8)) & 0xFF),
        "Checksum7": (section1[0x15], sum(section1[0x06 + i] for i in range(14)) & 0xFF),
    }
    if section2_decrypted is not None:
        checks["Checksum8"] = (section1[0x1A], checksum_every_0x20(section2_decrypted))
    return [
        f"{name}: expected 0x{expected:02X}, got 0x{actual:02X}"
        for name, (actual, expected) in checks.items()
        if actual != expected
    ]


def parse_dat(path: Path) -> ParsedSave:
    raw = path.read_bytes()
    if len(raw) < HEADER_SIZE:
        raise SaveFormatError("File is too small to be an XV2 Switch save.")
    section1 = bytearray(aes_ctr_xv2(SECTION1_KEY, SECTION1_COUNTER, raw[:HEADER_SIZE]))
    if section1[:5] != MAGIC:
        raise SaveFormatError("Header did not decrypt to #SAV\\0. Wrong file or unsupported format.")
    size = int.from_bytes(section1[0x7C:0x80], "little")
    end = HEADER_SIZE + size
    if end > len(raw):
        raise SaveFormatError("The encrypted section size is larger than the file.")
    encrypted = raw[HEADER_SIZE:end]
    key, counter = select_section2_crypto(section1)
    section2 = bytearray(aes_ctr_xv2(key, counter, encrypted))
    if section2[:5] != MAGIC:
        raise SaveFormatError("Save body did not decrypt to #SAV\\0.")
    failures = validate(section1, encrypted, section2)
    if failures:
        raise SaveFormatError("Checksum validation failed: " + "; ".join(failures))
    return ParsedSave(raw, section1, encrypted, section2, raw[end:])


def encrypt_dat(parsed: ParsedSave, section2: bytes) -> bytes:
    section1 = bytearray(parsed.section1)
    key, counter = select_section2_crypto(section1)
    encrypted = aes_ctr_xv2(key, counter, section2)
    update_header_checksums(section1, encrypted, section2)
    failures = validate(section1, encrypted, section2)
    if failures:
        raise RuntimeError("Internal checksum update failed: " + "; ".join(failures))
    return aes_ctr_xv2(SECTION1_KEY, SECTION1_COUNTER, bytes(section1)) + encrypted + parsed.trailing


def read_inventory(buf: bytes, table: InventoryTable) -> dict[int, bytes]:
    records: dict[int, bytes] = {}
    for off in range(table.start, table.end, 8):
        rec = bytes(buf[off:off + 8])
        if rec == EMPTY_INV:
            continue
        if len(rec) != 8 or rec[4] != table.category or rec[7] != 0:
            raise SaveFormatError(
                f"Unexpected record in {table.label} at 0x{off:X}: {rec.hex()}"
            )
        item_id = int.from_bytes(rec[:4], "little")
        # One record per item ID; preserve the first exact record/quantity.
        records.setdefault(item_id, rec)
    return records


def make_inventory_record(item_id: int, category: int, quantity: int = 1) -> bytes:
    return item_id.to_bytes(4, "little") + bytes([category]) + quantity.to_bytes(2, "little") + b"\x00"


def merge_inventory(buf: bytearray, key: str) -> tuple[int, int, int]:
    table = TABLES[key]
    existing = read_inventory(buf, table)
    target = set(TARGET_IDS[key])
    all_ids = sorted(set(existing) | target)
    capacity = (table.end - table.start) // 8
    if len(all_ids) > capacity:
        raise SaveFormatError(
            f"{table.label} needs {len(all_ids)} records but the known table has {capacity} slots."
        )
    before = len(existing)
    buf[table.start:table.end] = EMPTY_INV * capacity
    for index, item_id in enumerate(all_ids):
        off = table.start + index * 8
        buf[off:off + 8] = existing.get(item_id, make_inventory_record(item_id, table.category, 1))
    return before, len(all_ids), len(target - set(existing))


def set_flag_block(buf: bytearray, offset: int, length: int = ACQUIRED_BLOCK_SIZE) -> None:
    if offset + length > len(buf):
        raise SaveFormatError(f"Flag block 0x{offset:X} is outside this save version.")
    buf[offset:offset + length] = b"\xFF" * length


def patch_artwork_1_to_900(buf: bytearray) -> list[str]:
    max_bit = ARTWORK_SAFE_MAX_ID - 1
    end = ARTWORK_BITSET_OFFSET + (max_bit // 8) + 1
    if end > len(buf):
        raise SaveFormatError("Artwork bitset is outside this save version.")
    changed = 0
    for artwork_id in range(1, ARTWORK_SAFE_MAX_ID + 1):
        bit_index = artwork_id - 1
        off = ARTWORK_BITSET_OFFSET + (bit_index // 8)
        mask = 1 << (bit_index % 8)
        if not (buf[off] & mask):
            buf[off] |= mask
            changed += 1
    return [
        f"Regular Artwork: IDs 1-{ARTWORK_SAFE_MAX_ID} enabled ({changed} newly flagged)",
        "Artwork IDs above 900 were left untouched to avoid crossing the confirmed bitset boundary",
    ]


def patch_all_clothing(buf: bytearray) -> list[str]:
    notes: list[str] = []
    for key in ("tops", "bottoms", "gloves", "shoes"):
        before, after, added = merge_inventory(buf, key)
        notes.append(f"{TABLES[key].label}: {before}->{after} records ({added} added)")
    for offset in (ACQUIRED_TOPS, ACQUIRED_BOTTOMS, ACQUIRED_GLOVES, ACQUIRED_SHOES):
        set_flag_block(buf, offset)
    notes.append("Clothing location-lookup flags: checked for the primary 512-entry blocks")
    notes.append("Note: final-update clothing IDs 529-542 are added to inventory; their newer lookup extension is not mapped")
    return notes


def patch_all_accessories(buf: bytearray) -> list[str]:
    before, after, added = merge_inventory(buf, "accessories")
    set_flag_block(buf, ACQUIRED_ACCESSORIES)
    return [
        f"Accessories: {before}->{after} records ({added} added)",
        "Accessory location-lookup flags: all checked",
    ]


def patch_all_super_souls(buf: bytearray) -> list[str]:
    before, after, added = merge_inventory(buf, "super_souls")
    set_flag_block(buf, ACQUIRED_SUPER_SOULS)
    if SUPER_SOUL_EXTENSION + 8 > len(buf):
        raise SaveFormatError("Super Soul lookup extension is outside this save version.")
    buf[SUPER_SOUL_EXTENSION:SUPER_SOUL_EXTENSION + 7] = b"\xFF" * 7
    # Low nibble completes the older 60-entry extension. Bit 7 is the
    # confirmed Location Lookup flag for Super Soul ID 863.
    buf[SUPER_SOUL_EXTENSION + 7] |= 0x8F
    return [
        f"Super Souls: {before}->{after} records ({added} added)",
        "Super Soul location-lookup flags: primary block + older extension + ID 863 checked",
        "Added confirmed 6-star Super Soul ID 863: I'll grant you just one wish",
    ]


def patch_all_skills(buf: bytearray) -> list[str]:
    notes: list[str] = []
    for label, start, count in SKILL_BLOCKS:
        end = start + count * 8
        if end > len(buf):
            raise SaveFormatError(f"{label} block is outside this save version.")
        changed = 0
        for off in range(start, end, 8):
            if buf[off] != 1:
                buf[off] = 1
                changed += 1
        notes.append(f"{label}: {count} records enabled ({changed} changed)")
    return notes


def find_compact_item_record(
    buf: bytes, label: str, category: int, item_id: int, start: int, end: int
) -> int:
    hits: list[int] = []
    stop = min(end, len(buf) - 8)
    for off in range(start, stop + 1):
        rec = buf[off:off + 8]
        if len(rec) == 8 and rec[2] == 0 and rec[3] == item_id and rec[4:7] == b"\x00\x00\x00" and rec[7] == category:
            hits.append(off)
    if not hits:
        raise SaveFormatError(f"Could not find the {label} record.")
    if len(hits) > 1:
        raise SaveFormatError(
            f"Found multiple possible {label} records: " + ", ".join(f"0x{x:X}" for x in hits)
        )
    return hits[0]


def set_compact_item_count(buf: bytearray, profile: tuple[str, int, int, int, int], count: int) -> str:
    label, category, item_id, start, end = profile
    off = find_compact_item_record(buf, label, category, item_id, start, end)
    old = buf[off]
    buf[off] = count
    return f"{label}: {old}->{count} at 0x{off:X} (other record flags preserved)"




def set_tp_medals(buf: bytearray, target: int = TP_TARGET) -> str:
    """Set the displayed TP total using the confirmed two-field calculation."""
    end = TP_ADJUST_OFFSET + 4
    if end > len(buf):
        raise SaveFormatError("TP medal fields are outside this save version.")
    base = int.from_bytes(buf[TP_BASE_OFFSET:TP_BASE_OFFSET + 4], "little", signed=True)
    old_adjust = int.from_bytes(buf[TP_ADJUST_OFFSET:TP_ADJUST_OFFSET + 4], "little", signed=True)
    old_total = base + old_adjust
    new_adjust = target - base
    if not -(1 << 31) <= new_adjust < (1 << 31):
        raise SaveFormatError("Requested TP medal value cannot fit the save field.")
    buf[TP_ADJUST_OFFSET:TP_ADJUST_OFFSET + 4] = new_adjust.to_bytes(4, "little", signed=True)
    return (
        f"TP medals: {old_total}->{target} "
        f"(base {base}, adjustment {old_adjust}->{new_adjust})"
    )

def patch_lobby_risky(buf: bytearray) -> list[str]:
    for start, end in (LOBBY_RISK_RANGE_1, LOBBY_RISK_RANGE_2):
        if end > len(buf):
            raise SaveFormatError("Lobby item patch range is outside this save version.")
        buf[start:end] = b"\xFF" * (end - start)
    return [
        "Experimental lobby mascot/aura/vehicle ranges enabled",
        "WARNING: launch the game and create a fresh in-game save before patching this save again",
    ]


def suggest_output(input_path: str) -> str:
    if not input_path:
        return ""
    p = Path(input_path)
    return str(p.with_name(p.stem + "_offline_patched" + p.suffix))


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"XV2 Switch Offline Patcher v{APP_VERSION}")
        self.geometry("820x690")
        self.minsize(720, 610)

        self.input_path = tk.StringVar()
        self.output_path = tk.StringVar()

        self.all_artwork = tk.BooleanVar(value=True)
        self.all_clothing = tk.BooleanVar(value=True)
        self.all_skills = tk.BooleanVar(value=True)
        self.all_accessories = tk.BooleanVar(value=True)
        self.zen_oh_99 = tk.BooleanVar(value=True)
        self.super_mix_99 = tk.BooleanVar(value=True)
        self.tp_99999 = tk.BooleanVar(value=True)
        self.all_super_souls = tk.BooleanVar(value=True)
        self.all_lobby_items = tk.BooleanVar(value=False)

        self._build_ui()
        if len(sys.argv) > 1:
            candidate = Path(sys.argv[1].strip('"')).expanduser()
            if candidate.exists():
                self.input_path.set(str(candidate))
                self.output_path.set(suggest_output(str(candidate)))
                self.log(f"Loaded dropped save: {candidate}\n")

    def _build_ui(self) -> None:
        pad = {"padx": 8, "pady": 5}

        file_box = tk.LabelFrame(self, text="Save file")
        file_box.pack(fill="x", **pad)
        file_box.columnconfigure(1, weight=1)
        tk.Label(file_box, text="Input savefile1.dat:").grid(row=0, column=0, sticky="w", **pad)
        tk.Entry(file_box, textvariable=self.input_path).grid(row=0, column=1, sticky="ew", **pad)
        tk.Button(file_box, text="Browse…", command=self.browse_input).grid(row=0, column=2, **pad)
        tk.Label(file_box, text="Output file:").grid(row=1, column=0, sticky="w", **pad)
        tk.Entry(file_box, textvariable=self.output_path).grid(row=1, column=1, sticky="ew", **pad)
        tk.Button(file_box, text="Save as…", command=self.browse_output).grid(row=1, column=2, **pad)
        tk.Label(
            file_box,
            text="Drag savefile1.dat onto the BAT launcher, or choose it here. The input is never overwritten.",
            fg="#555555",
        ).grid(row=2, column=0, columnspan=3, sticky="w", **pad)

        options = tk.LabelFrame(self, text="Choose patches")
        options.pack(fill="x", **pad)
        options.columnconfigure(0, weight=1)
        options.columnconfigure(1, weight=1)

        tk.Checkbutton(options, text="All regular Artwork (IDs 1-900)", variable=self.all_artwork).grid(row=0, column=0, sticky="w", **pad)
        tk.Label(options, text="900 is the confirmed safe boundary; newer Artwork is left untouched.", fg="#555555").grid(row=0, column=1, sticky="w", **pad)
        tk.Checkbutton(options, text="All clothing (tops, bottoms, gloves, shoes)", variable=self.all_clothing).grid(row=1, column=0, sticky="w", **pad)
        tk.Checkbutton(options, text="All skills (Super, Ultimate, Evasive, Awoken)", variable=self.all_skills).grid(row=1, column=1, sticky="w", **pad)
        tk.Checkbutton(options, text="All accessories", variable=self.all_accessories).grid(row=2, column=0, sticky="w", **pad)
        tk.Checkbutton(options, text="All Super Souls", variable=self.all_super_souls).grid(row=2, column=1, sticky="w", **pad)
        tk.Checkbutton(options, text="99 Zen-Oh Buttons", variable=self.zen_oh_99).grid(row=3, column=0, sticky="w", **pad)
        tk.Checkbutton(options, text="99 Super Mix Capsule Z", variable=self.super_mix_99).grid(row=3, column=1, sticky="w", **pad)
        tk.Checkbutton(options, text="99,999 TP Medals", variable=self.tp_99999).grid(row=4, column=0, sticky="w", **pad)
        tk.Label(options, text="Uses the confirmed two-field TP calculation.", fg="#555555").grid(row=4, column=1, sticky="w", **pad)

        risky = tk.Checkbutton(
            options,
            text="ALL LOBBY ITEMS — EXPERIMENTAL / FRESH SAVE REQUIRED",
            variable=self.all_lobby_items,
            fg="#9b0000",
            activeforeground="#9b0000",
        )
        risky.grid(row=5, column=0, columnspan=2, sticky="w", **pad)
        tk.Label(
            options,
            text="May alter TP calculation state. Restore, launch the game, and save once before patching again.",
            fg="#9b0000",
        ).grid(row=6, column=0, columnspan=2, sticky="w", padx=28, pady=(0, 2))
        tk.Label(
            options,
            text="After using Lobby Items, launch the game and create a fresh in-game save before patching again.",
            fg="#9b0000",
        ).grid(row=7, column=0, columnspan=2, sticky="w", padx=28, pady=(0, 6))

        controls = tk.Frame(self)
        controls.pack(fill="x", **pad)
        tk.Button(controls, text="Patch Save", command=self.patch_save, height=2, width=18).pack(side="left", padx=6)
        tk.Button(controls, text="Safe defaults", command=self.safe_defaults).pack(side="left", padx=6)
        tk.Button(controls, text="Clear all", command=self.clear_all).pack(side="left", padx=6)
        tk.Button(controls, text="Open README", command=self.open_readme).pack(side="left", padx=6)

        self.text = ScrolledText(self, height=22, wrap="word")
        self.text.pack(fill="both", expand=True, padx=8, pady=8)
        self.log("Ready. Keep your original save backed up. The launcher writes a separate file.\n")

    def log(self, text: str) -> None:
        self.text.insert("end", text)
        self.text.see("end")
        self.update_idletasks()

    def browse_input(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose Switch savefile1.dat",
            filetypes=[("DAT save", "*.dat"), ("All files", "*.*")],
        )
        if path:
            self.input_path.set(path)
            self.output_path.set(suggest_output(path))

    def browse_output(self) -> None:
        initial = suggest_output(self.input_path.get()) or "savefile1_offline_patched.dat"
        path = filedialog.asksaveasfilename(
            title="Write patched save",
            initialfile=Path(initial).name,
            defaultextension=".dat",
            filetypes=[("DAT save", "*.dat"), ("All files", "*.*")],
        )
        if path:
            self.output_path.set(path)

    def safe_defaults(self) -> None:
        self.all_artwork.set(True)
        self.all_clothing.set(True)
        self.all_skills.set(True)
        self.all_accessories.set(True)
        self.zen_oh_99.set(True)
        self.super_mix_99.set(True)
        self.tp_99999.set(True)
        self.all_super_souls.set(True)
        self.all_lobby_items.set(False)
        self.log("Safe defaults selected. Lobby items remain OFF.\n")

    def clear_all(self) -> None:
        for value in (
            self.all_artwork,
            self.all_clothing,
            self.all_skills,
            self.all_accessories,
            self.zen_oh_99,
            self.super_mix_99,
            self.tp_99999,
            self.all_super_souls,
            self.all_lobby_items,
        ):
            value.set(False)

    def open_readme(self) -> None:
        readme = Path(__file__).resolve().with_name("README_XV2_SWITCH_PATCHER.txt")
        if not readme.exists():
            messagebox.showerror("README missing", f"Could not find {readme.name}")
            return
        try:
            import os
            os.startfile(str(readme))  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo("README", str(readme))

    def selected_anything(self) -> bool:
        return any(
            x.get()
            for x in (
                self.all_artwork,
                self.all_clothing,
                self.all_skills,
                self.all_accessories,
                self.zen_oh_99,
                self.super_mix_99,
                self.tp_99999,
                self.all_super_souls,
                self.all_lobby_items,
            )
        )

    def patch_save(self) -> None:
        try:
            inp = Path(self.input_path.get().strip())
            out = Path(self.output_path.get().strip() or suggest_output(str(inp)))
            if not inp.exists():
                raise FileNotFoundError("Choose a valid savefile1.dat first.")
            if inp.resolve() == out.resolve():
                raise ValueError("Refusing to overwrite the input save. Choose a different output file.")
            if not self.selected_anything():
                raise ValueError("Select at least one patch option.")
            if out.exists() and not messagebox.askyesno("Overwrite output?", f"The output already exists:\n{out}\n\nOverwrite it?"):
                return

            if self.all_lobby_items.get():
                warning = (
                    "LOBBY ITEM PATCH — FRESH IN-GAME SAVE REQUIRED\n\n"
                    "This experimental patch unlocks lobby items and changes the game's TP calculation state.\n\n"
                    "AFTER RESTORING THIS OUTPUT: launch Xenoverse 2, let it create a new save, then export that fresh save before running this patcher again.\n\n"
                    "DO NOT PATCH THE SAME GENERATED OUTPUT TWICE.\n\n"
                    "Continue anyway?"
                )
                if not messagebox.askyesno("LOBBY ITEM WARNING", warning, icon="warning"):
                    return

            self.log(f"\nReading: {inp}\n")
            parsed = parse_dat(inp)
            buf = bytearray(parsed.section2)
            notes: list[str] = []

            if self.all_artwork.get():
                notes.extend(patch_artwork_1_to_900(buf))
            if self.all_clothing.get():
                notes.extend(patch_all_clothing(buf))
            if self.all_accessories.get():
                notes.extend(patch_all_accessories(buf))
            if self.all_super_souls.get():
                notes.extend(patch_all_super_souls(buf))
            if self.all_skills.get():
                notes.extend(patch_all_skills(buf))
            if self.zen_oh_99.get():
                notes.append(set_compact_item_count(buf, ZEN_OH_BUTTON, 99))
            if self.super_mix_99.get():
                notes.append(set_compact_item_count(buf, SUPER_MIX_Z, 99))
            if self.all_lobby_items.get():
                notes.extend(patch_lobby_risky(buf))
            if self.tp_99999.get():
                notes.append(set_tp_medals(buf, TP_TARGET))

            output_bytes = encrypt_dat(parsed, bytes(buf))
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(output_bytes)

            # Full decrypt/checksum validation of the written output.
            verified = parse_dat(out)
            if verified.section2 != buf:
                raise RuntimeError("Output validation decrypted to different data.")

            self.log("Applied:\n")
            for note in notes:
                self.log(f"  • {note}\n")
            self.log(f"Wrote: {out}\n")
            self.log(f"SHA-256: {hashlib.sha256(output_bytes).hexdigest()}\n")
            self.log("Validation: PASS\n")
            completion = f"Patched save written successfully:\n\n{out}"
            if self.all_lobby_items.get():
                completion += (
                    "\n\nIMPORTANT: Restore this output, launch the game, and create a fresh in-game "
                    "save before using the patcher again."
                )
            messagebox.showinfo("Patch complete", completion)
        except Exception as exc:
            self.log("\nERROR:\n" + traceback.format_exc() + "\n")
            messagebox.showerror("Patch failed", str(exc))


def main() -> int:
    app = App()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
