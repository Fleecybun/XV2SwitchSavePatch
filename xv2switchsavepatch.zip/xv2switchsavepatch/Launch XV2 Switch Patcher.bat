@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 "xv2_switch_offline_gui_patcher.py" %*
    goto :done
)

where python >nul 2>nul
if %errorlevel%==0 (
    python "xv2_switch_offline_gui_patcher.py" %*
    goto :done
)

echo.
echo ERROR: Python 3 was not found.
echo Install Python 3 for Windows and enable "Add Python to PATH".
echo.
pause
exit /b 1

:done
if errorlevel 1 pause
endlocal
