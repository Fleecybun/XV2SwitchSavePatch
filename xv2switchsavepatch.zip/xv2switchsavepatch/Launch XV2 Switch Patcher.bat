@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>&1
if not errorlevel 1 goto USE_PY

where python >nul 2>&1
if not errorlevel 1 goto USE_PYTHON

echo.
echo ERROR: Python 3 was not found.
echo Install Python 3, then read README_XV2_SWITCH_PATCHER.txt.
echo.
start "" "%~dp0README_XV2_SWITCH_PATCHER.txt"
pause
exit /b 1

:USE_PY
py -3 -c "import cryptography" >nul 2>&1
if errorlevel 1 goto MISSING_CRYPTO_PY
py -3 "%~dp0xv2_switch_offline_gui_patcher.py" %*
if errorlevel 1 pause
exit /b %errorlevel%

:USE_PYTHON
python -c "import cryptography" >nul 2>&1
if errorlevel 1 goto MISSING_CRYPTO_PYTHON
python "%~dp0xv2_switch_offline_gui_patcher.py" %*
if errorlevel 1 pause
exit /b %errorlevel%

:MISSING_CRYPTO_PY
echo.
echo ERROR: The Python package "cryptography" is missing.
echo Run: py -3 -m pip install cryptography
echo Then read README_XV2_SWITCH_PATCHER.txt.
echo.
start "" "%~dp0README_XV2_SWITCH_PATCHER.txt"
pause
exit /b 2

:MISSING_CRYPTO_PYTHON
echo.
echo ERROR: The Python package "cryptography" is missing.
echo Run: python -m pip install cryptography
echo Then read README_XV2_SWITCH_PATCHER.txt.
echo.
start "" "%~dp0README_XV2_SWITCH_PATCHER.txt"
pause
exit /b 2
