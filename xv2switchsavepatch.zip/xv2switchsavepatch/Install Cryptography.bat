@echo off
setlocal
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 -m pip install --upgrade cryptography
) else (
    python -m pip install --upgrade cryptography
)
echo.
pause
endlocal
