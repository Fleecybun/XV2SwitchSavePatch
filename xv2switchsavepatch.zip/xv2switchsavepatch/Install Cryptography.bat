@echo off
setlocal
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -m pip install cryptography
  pause
  exit /b %errorlevel%
)
where python >nul 2>&1
if not errorlevel 1 (
  python -m pip install cryptography
  pause
  exit /b %errorlevel%
)
echo ERROR: Python 3 was not found. Read README_XV2_SWITCH_PATCHER.txt.
pause
exit /b 1
